package com.senai.template.controllers;

import com.senai.template.dtos.UsuarioDto;
import com.senai.template.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class PageController {

	private final UsuarioService usuarioService;

	public PageController(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}

	/* LOGIN */

	@GetMapping("/")
	public String index() {
		return "redirect:/login";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@PostMapping("/login")
	public String realizarLogin(@RequestParam String email,
								@RequestParam String senha,
								Model model,
								RedirectAttributes redirectAttributes) {
		UsuarioDto usuarioDto = usuarioService.autenticar(email, senha);

		if (usuarioDto == null) {
			model.addAttribute("erro", "E-mail ou senha invalidos.");
			model.addAttribute("email", email);
			return "login";
		}

		redirectAttributes.addFlashAttribute("mensagem", "Bem-vindo, " + usuarioDto.getNome() + ".");
		return "redirect:/home";
	}

	/* LOGIN - FIM */

	/* HOME - INICIO */

	@GetMapping("/home")
	public String home() {
		return "home";
	}

	/* USUARIO */

	@GetMapping("/usuariolista")
	public String usuariolista() {
		return "redirect:/usuarios";
	}

	/* USUARIO - FIM */
}

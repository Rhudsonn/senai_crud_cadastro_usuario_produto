package com.senai.template.services;

import com.senai.template.dtos.UsuarioDto;
import com.senai.template.entities.UsuarioEntity;
import com.senai.template.repositories.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<UsuarioDto> listarTodos() {
        List<UsuarioEntity> usuariosEntity = usuarioRepository.findAll();
        List<UsuarioDto> usuariosDto = new ArrayList<>();

        for (UsuarioEntity usuarioEntity : usuariosEntity) {
            UsuarioDto usuarioDto = converterEntityParaDto(usuarioEntity);
            usuariosDto.add(usuarioDto);
        }

        return usuariosDto;
    }

    public UsuarioDto buscarPorId(Long id) {
        UsuarioEntity usuarioEntity = usuarioRepository.findById(id).orElseThrow();
        return converterEntityParaDto(usuarioEntity);
    }

    public void salvar(UsuarioDto usuarioDto) {
        UsuarioEntity usuarioEntity = converterDtoParaEntity(usuarioDto);
        usuarioRepository.save(usuarioEntity);
    }

    public void atualizar(UsuarioDto usuarioDto) {
        UsuarioEntity usuarioEntity = usuarioRepository.findById(usuarioDto.getId()).orElseThrow();

        usuarioEntity.setNome(usuarioDto.getNome());
        usuarioEntity.setEmail(usuarioDto.getEmail());
        usuarioEntity.setSenha(usuarioDto.getSenha());

        usuarioRepository.save(usuarioEntity);
    }

    public void excluir(Long id) {
        usuarioRepository.deleteById(id);
    }

    public UsuarioDto autenticar(String email, String senha) {
        Optional<UsuarioEntity> usuarioEntityOptional = usuarioRepository.findByEmailAndSenha(email, senha);

        if (usuarioEntityOptional.isEmpty()) {
            return null;
        }

        UsuarioEntity usuarioEntity = usuarioEntityOptional.get();
        return converterEntityParaDto(usuarioEntity);
    }

    private UsuarioEntity converterDtoParaEntity(UsuarioDto usuarioDto) {
        UsuarioEntity usuarioEntity = new UsuarioEntity();

        usuarioEntity.setId(usuarioDto.getId());
        usuarioEntity.setNome(usuarioDto.getNome());
        usuarioEntity.setEmail(usuarioDto.getEmail());
        usuarioEntity.setSenha(usuarioDto.getSenha());

        return usuarioEntity;
    }

    private UsuarioDto converterEntityParaDto(UsuarioEntity usuarioEntity) {
        UsuarioDto usuarioDto = new UsuarioDto();

        usuarioDto.setId(usuarioEntity.getId());
        usuarioDto.setNome(usuarioEntity.getNome());
        usuarioDto.setEmail(usuarioEntity.getEmail());
        usuarioDto.setSenha(usuarioEntity.getSenha());

        return usuarioDto;
    }
}

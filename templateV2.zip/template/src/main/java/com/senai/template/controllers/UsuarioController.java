package com.senai.template.controllers;

import com.senai.template.dtos.UsuarioDto;
import com.senai.template.services.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("usuarios", usuarioService.listarTodos());
        return "usuariolista";
    }

    @GetMapping("/inserir")
    public String abrirFormularioInserir(Model model) {
        model.addAttribute("usuario", new UsuarioDto());
        return "usuarioinserir";
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("usuario") UsuarioDto usuarioDto,
                         BindingResult bindingResult,
                         RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "usuarioinserir";
        }

        usuarioService.salvar(usuarioDto);
        redirectAttributes.addFlashAttribute("mensagem", "Usuario cadastrado com sucesso.");

        return "redirect:/usuarios";
    }

    @GetMapping("/atualizar/{id}")
    public String abrirFormularioAtualizar(@PathVariable Long id, Model model) {
        UsuarioDto usuarioDto = usuarioService.buscarPorId(id);
        model.addAttribute("usuario", usuarioDto);

        return "usuarioatualizar";
    }

    @PostMapping("/atualizar")
    public String atualizar(@Valid @ModelAttribute("usuario") UsuarioDto usuarioDto,
                            BindingResult bindingResult,
                            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "usuarioatualizar";
        }

        usuarioService.atualizar(usuarioDto);
        redirectAttributes.addFlashAttribute("mensagem", "Usuario atualizado com sucesso.");

        return "redirect:/usuarios";
    }

    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        usuarioService.excluir(id);
        redirectAttributes.addFlashAttribute("mensagem", "Usuario excluido com sucesso.");

        return "redirect:/usuarios";
    }
}

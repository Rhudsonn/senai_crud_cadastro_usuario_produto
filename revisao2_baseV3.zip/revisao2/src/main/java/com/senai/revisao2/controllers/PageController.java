package com.senai.revisao2.controllers;

import com.senai.revisao2.dtos.UsuarioDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class PageController {

    @GetMapping("/")
    public String getIndex(){
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String getLogin(){
        return "login";
    }

    @GetMapping("/home")
    public String getHome(){
        return "home";
    }

    @GetMapping("/usuariolista")
    public String getUsuarioLista(Model model){

        List<UsuarioDto> usuarioDtoLita = new ArrayList();

        UsuarioDto usuario1 = new UsuarioDto();
        usuario1.setId(1L);
        usuario1.setNome("Marlos");
        usuario1.setEmail("marlos@senai.br");

        usuarioDtoLita.add(usuario1);

        UsuarioDto usuario2 = new UsuarioDto();
        usuario2.setId(2L);
        usuario2.setNome("Maria");
        usuario2.setEmail("maria@senai.br");

        usuarioDtoLita.add(usuario2);

        model.addAttribute("usuarios",usuarioDtoLita);

        return "usuariolista";

    }

}
